/* ═══════════════════════════════════════════════════════════
   app.js — PathFinder
   • Tries to load the Emscripten-compiled WASM module first.
   • Falls back to a pure-JS A* / Dijkstra implementation that
     mirrors the C++ logic exactly.
   • Renders everything on a <canvas> with an async animation loop.
   ═══════════════════════════════════════════════════════════ */

'use strict';

/* ────────────────────────────────────────────────────────────
   0. CONSTANTS & CELL TYPES
   ──────────────────────────────────────────────────────────── */
const CELL = { OPEN: 0, WALL: 1, START: 2, END: 3 };

const COLORS = {
  open:        '#0d1526',
  wall:        '#2a3349',
  wallBorder:  '#334060',
  start:       '#22d3ee',
  startGlow:   'rgba(34,211,238,0.5)',
  end:         '#f472b6',
  endGlow:     'rgba(244,114,182,0.5)',
  visited:     '#1e3a6e',
  visitedBord: '#2563eb',
  frontier:    '#1d4ed8',
  path:        '#f59e0b',
  pathGlow:    'rgba(245,158,11,0.45)',
  grid:        'rgba(255,255,255,0.04)',
};

/* ────────────────────────────────────────────────────────────
   1. PURE-JS PATHFINDING ENGINE (mirrors the C++ implementation)
   ──────────────────────────────────────────────────────────── */

// Custom Min-Heap (matches the C++ MinHeap)
class MinHeap {
  constructor() { this._h = []; }
  get size()  { return this._h.length; }
  get empty() { return this._h.length === 0; }

  push(cost, index) {
    this._h.push({ cost, index });
    this._siftUp(this._h.length - 1);
  }

  pop() {
    const top = this._h[0];
    const last = this._h.pop();
    if (this._h.length > 0) { this._h[0] = last; this._siftDown(0); }
    return top;
  }

  _siftUp(i) {
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this._h[p].cost > this._h[i].cost) {
        [this._h[p], this._h[i]] = [this._h[i], this._h[p]];
        i = p;
      } else break;
    }
  }

  _siftDown(i) {
    const n = this._h.length;
    while (true) {
      let s = i, l = 2*i+1, r = 2*i+2;
      if (l < n && this._h[l].cost < this._h[s].cost) s = l;
      if (r < n && this._h[r].cost < this._h[s].cost) s = r;
      if (s !== i) { [this._h[s], this._h[i]] = [this._h[i], this._h[s]]; i = s; }
      else break;
    }
  }
}

// 8-directional offsets & costs
const DR = [-1,-1,-1, 0, 0, 1, 1, 1];
const DC = [-1, 0, 1,-1, 1,-1, 0, 1];
const MOVE_COST = [1.414,1,1.414,1,1,1.414,1,1.414];

function octile(a, b, cols) {
  const dx = Math.abs((a % cols) - (b % cols));
  const dy = Math.abs(Math.floor(a / cols) - Math.floor(b / cols));
  return (dx + dy) + (1.414 - 2) * Math.min(dx, dy);
}

/**
 * JS pathfinding — returns { visitOrder, path }
 * algo: 'astar' | 'dijkstra'
 */
function jsPathfind(grid, rows, cols, start, end, algo) {
  const n = rows * cols;
  const INF = 1e30;
  const gScore   = new Float32Array(n).fill(INF);
  const cameFrom = new Int32Array(n).fill(-1);
  const closed   = new Uint8Array(n);
  const visitOrder = [];

  gScore[start] = 0;
  const hStart = algo === 'astar' ? octile(start, end, cols) : 0;

  const pq = new MinHeap();
  pq.push(hStart, start);

  let found = false;

  while (!pq.empty) {
    const { index: u } = pq.pop();
    if (closed[u]) continue;
    closed[u] = 1;
    visitOrder.push(u);

    if (u === end) { found = true; break; }

    const ur = Math.floor(u / cols), uc = u % cols;

    for (let d = 0; d < 8; d++) {
      const nr = ur + DR[d], nc = uc + DC[d];
      if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue;
      const v = nr * cols + nc;
      if (grid[v] === CELL.WALL || closed[v]) continue;

      // Diagonal corner-cutting prevention
      if (d === 0 || d === 2 || d === 5 || d === 7) {
        const r1 = ur + DR[d], c1 = uc;
        const r2 = ur,         c2 = uc + DC[d];
        if (r1 >= 0 && r1 < rows && c1 >= 0 && c1 < cols && grid[r1*cols+c1] === CELL.WALL) continue;
        if (r2 >= 0 && r2 < rows && c2 >= 0 && c2 < cols && grid[r2*cols+c2] === CELL.WALL) continue;
      }

      const tentative = gScore[u] + MOVE_COST[d];
      if (tentative < gScore[v]) {
        cameFrom[v] = u;
        gScore[v]   = tentative;
        const h = algo === 'astar' ? octile(v, end, cols) : 0;
        pq.push(tentative + h, v);
      }
    }
  }

  const path = [];
  if (found) {
    let cur = end;
    while (cur !== -1) { path.push(cur); cur = cameFrom[cur]; }
    path.reverse();
  }

  return { visitOrder, path };
}

/* ────────────────────────────────────────────────────────────
   2. WASM BRIDGE
   ──────────────────────────────────────────────────────────── */
let wasmModule = null;

async function tryLoadWasm() {
  if (typeof PathfinderModule !== 'function') return false;
  try {
    wasmModule = await PathfinderModule();
    console.log('[PathFinder] WASM module loaded successfully');
    return true;
  } catch (e) {
    console.warn('[PathFinder] WASM load failed, falling back to JS engine', e);
    return false;
  }
}

function wasmPathfind(grid, rows, cols, start, end) {
  const m = wasmModule;
  const n = rows * cols;

  // Allocate grid in WASM heap
  const ptr = m._malloc(n * 4);
  const heap = new Int32Array(m.HEAP32.buffer, ptr, n);
  for (let i = 0; i < n; i++) heap[i] = grid[i];

  // Call C++ findPath
  const resPtr = m._findPath(ptr, rows, cols, start, end);
  m._free(ptr);

  const resLen = m._getResultLength();
  const result = new Int32Array(m.HEAP32.buffer, resPtr, resLen);

  const visitCount = result[0];
  const visitOrder = Array.from(result.slice(1, 1 + visitCount));
  const pathLen    = result[1 + visitCount];
  const path       = Array.from(result.slice(1 + visitCount + 1, 1 + visitCount + 1 + pathLen));

  m._freeResult();
  return { visitOrder, path };
}

/* ────────────────────────────────────────────────────────────
   3. GRID STATE
   ──────────────────────────────────────────────────────────── */
let COLS = 30, ROWS = 20;
let grid       = new Uint8Array(ROWS * COLS);
let visitedSet = new Uint8Array(ROWS * COLS);
let pathSet    = new Uint8Array(ROWS * COLS);
let startNode  = -1, endNode = -1;
let currentTool = 'wall';
let currentAlgo = 'astar';
let isRunning   = false;
let animFrameId = null;

// Speed → delay in ms
const SPEED_MAP = { 1: 80, 2: 30, 3: 12, 4: 3, 5: 0 };
let animDelay = 3;

function initGrid(cols, rows) {
  COLS = cols; ROWS = rows;
  grid       = new Uint8Array(ROWS * COLS);
  visitedSet = new Uint8Array(ROWS * COLS);
  pathSet    = new Uint8Array(ROWS * COLS);

  // Default start/end
  startNode = Math.floor(ROWS / 2) * COLS + Math.floor(COLS * 0.15);
  endNode   = Math.floor(ROWS / 2) * COLS + Math.floor(COLS * 0.85);
  grid[startNode] = CELL.START;
  grid[endNode]   = CELL.END;
}

function clearPath() {
  visitedSet.fill(0);
  pathSet.fill(0);
}

function clearAll() {
  grid.fill(CELL.OPEN);
  clearPath();
  grid[startNode] = CELL.START;
  grid[endNode]   = CELL.END;
}

/* ────────────────────────────────────────────────────────────
   4. CANVAS RENDERER
   ──────────────────────────────────────────────────────────── */
const canvas = document.getElementById('grid-canvas');
const ctx    = canvas.getContext('2d');

let cellSize = 24;

function resize() {
  const container = document.getElementById('grid-container');
  const w = container.clientWidth  - 32;
  const h = container.clientHeight - 32;
  cellSize = Math.max(8, Math.min(Math.floor(w / COLS), Math.floor(h / ROWS)));
  canvas.width  = cellSize * COLS;
  canvas.height = cellSize * ROWS;
  render();
}

function drawCell(col, row, fillStyle, glowColor) {
  const x = col * cellSize, y = row * cellSize;
  const pad = cellSize > 10 ? 1 : 0;

  if (glowColor && cellSize >= 12) {
    ctx.shadowBlur  = cellSize * 0.9;
    ctx.shadowColor = glowColor;
  } else {
    ctx.shadowBlur = 0;
  }

  ctx.fillStyle = fillStyle;
  ctx.fillRect(x + pad, y + pad, cellSize - pad * 2, cellSize - pad * 2);
  ctx.shadowBlur = 0;
}

function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Background
  ctx.fillStyle = COLORS.open;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const idx = row * COLS + col;
      const cell = grid[idx];

      if (cell === CELL.START) {
        drawCell(col, row, COLORS.start, COLORS.startGlow);
      } else if (cell === CELL.END) {
        drawCell(col, row, COLORS.end, COLORS.endGlow);
      } else if (cell === CELL.WALL) {
        ctx.fillStyle = COLORS.wall;
        const x = col * cellSize, y = row * cellSize;
        ctx.fillRect(x, y, cellSize, cellSize);
        if (cellSize > 10) {
          ctx.fillStyle = COLORS.wallBorder;
          ctx.fillRect(x, y, cellSize, 1);
          ctx.fillRect(x, y, 1, cellSize);
        }
      } else if (pathSet[idx]) {
        drawCell(col, row, COLORS.path, COLORS.pathGlow);
      } else if (visitedSet[idx]) {
        const x = col * cellSize, y = row * cellSize;
        ctx.fillStyle = COLORS.visited;
        ctx.fillRect(x, y, cellSize, cellSize);
        if (cellSize > 10) {
          ctx.fillStyle = COLORS.visitedBord;
          ctx.fillRect(x + cellSize - 1, y, 1, cellSize);
          ctx.fillRect(x, y + cellSize - 1, cellSize, 1);
        }
      }
    }
  }

  // Grid lines
  if (cellSize >= 10) {
    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth   = 1;
    for (let c = 0; c <= COLS; c++) {
      ctx.beginPath();
      ctx.moveTo(c * cellSize, 0);
      ctx.lineTo(c * cellSize, canvas.height);
      ctx.stroke();
    }
    for (let r = 0; r <= ROWS; r++) {
      ctx.beginPath();
      ctx.moveTo(0, r * cellSize);
      ctx.lineTo(canvas.width, r * cellSize);
      ctx.stroke();
    }
  }
}

/* ────────────────────────────────────────────────────────────
   5. ANIMATION LOOP
   ──────────────────────────────────────────────────────────── */
function sleep(ms) {
  return ms > 0 ? new Promise(r => setTimeout(r, ms)) : Promise.resolve();
}

async function animate(visitOrder, path) {
  isRunning = true;

  // Animate visited cells
  const batchSize = animDelay === 0 ? visitOrder.length : 1;
  for (let i = 0; i < visitOrder.length; i += batchSize) {
    for (let b = 0; b < batchSize && i + b < visitOrder.length; b++) {
      const idx = visitOrder[i + b];
      if (grid[idx] !== CELL.START && grid[idx] !== CELL.END) {
        visitedSet[idx] = 1;
      }
    }
    updateStats(i + batchSize, null);
    render();
    await sleep(animDelay);
  }

  // Animate path
  if (path.length > 0) {
    for (const idx of path) {
      if (grid[idx] !== CELL.START && grid[idx] !== CELL.END) pathSet[idx] = 1;
      render();
      await sleep(animDelay === 0 ? 0 : 18);
    }
  } else {
    showToast('No path found! The destination is unreachable.');
  }

  updateStats(visitOrder.length, path.length);
  isRunning = false;
}

/* ────────────────────────────────────────────────────────────
   6. MAZE GENERATOR (Recursive Division)
   ──────────────────────────────────────────────────────────── */
function generateMaze() {
  if (isRunning) return;
  clearPath();
  grid.fill(CELL.WALL);

  // Carve passages
  function carve(r, c) {
    const dirs = [[0,2],[0,-2],[2,0],[-2,0]].sort(() => Math.random() - 0.5);
    for (const [dr, dc] of dirs) {
      const nr = r + dr, nc = c + dc;
      if (nr > 0 && nr < ROWS-1 && nc > 0 && nc < COLS-1 && grid[nr*COLS+nc] === CELL.WALL) {
        grid[(r + dr/2)*COLS + (c + dc/2)] = CELL.OPEN;
        grid[nr*COLS+nc] = CELL.OPEN;
        carve(nr, nc);
      }
    }
  }

  // Start from odd-indexed cell
  const sr = 1, sc = 1;
  grid[sr*COLS+sc] = CELL.OPEN;
  carve(sr, sc);

  // Restore start/end
  grid[startNode] = CELL.START;
  grid[endNode]   = CELL.END;
  // Open cells around start/end so paths can form
  [[0,1],[0,-1],[1,0],[-1,0]].forEach(([dr,dc]) => {
    const r1 = Math.floor(startNode/COLS)+dr, c1 = startNode%COLS+dc;
    const r2 = Math.floor(endNode/COLS)+dr,   c2 = endNode%COLS+dc;
    if (r1>=0&&r1<ROWS&&c1>=0&&c1<COLS) grid[r1*COLS+c1] = CELL.OPEN;
    if (r2>=0&&r2<ROWS&&c2>=0&&c2<COLS) grid[r2*COLS+c2] = CELL.OPEN;
  });

  render();
}

/* ────────────────────────────────────────────────────────────
   7. RUN PATHFINDING
   ──────────────────────────────────────────────────────────── */
async function runPathfind() {
  if (isRunning) return;
  if (startNode < 0 || endNode < 0) { showToast('Place a start and end node first!'); return; }

  clearPath();
  render();

  const t0 = performance.now();

  let result;
  if (wasmModule) {
    result = wasmPathfind(grid, ROWS, COLS, startNode, endNode);
  } else {
    result = jsPathfind(grid, ROWS, COLS, startNode, endNode, currentAlgo);
  }

  const elapsed = (performance.now() - t0).toFixed(2);
  document.getElementById('stat-time').textContent = elapsed + ' ms';

  await animate(result.visitOrder, result.path);
}

/* ────────────────────────────────────────────────────────────
   8. UI STATS & TOAST
   ──────────────────────────────────────────────────────────── */
function updateStats(visited, pathLen) {
  document.getElementById('stat-visited').textContent = visited !== null ? visited : '—';
  if (pathLen !== null)
    document.getElementById('stat-path').textContent = pathLen > 0 ? pathLen + ' cells' : 'None';
}

function showToast(msg) {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.style.cssText = `
      position:fixed; bottom:28px; left:50%; transform:translateX(-50%);
      background:rgba(15,23,42,0.92); backdrop-filter:blur(12px);
      border:1px solid rgba(244,114,182,0.3); color:#f472b6;
      padding:10px 22px; border-radius:12px; font-size:0.85rem;
      font-family:Inter,sans-serif; z-index:9999; pointer-events:none;
      transition:opacity 0.4s;
    `;
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.opacity = '1';
  setTimeout(() => { t.style.opacity = '0'; }, 2800);
}

/* ────────────────────────────────────────────────────────────
   9. CANVAS MOUSE / TOUCH EVENTS
   ──────────────────────────────────────────────────────────── */
let isPainting = false;

function cellFromEvent(e) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width  / rect.width;
  const scaleY = canvas.height / rect.height;
  const clientX = e.touches ? e.touches[0].clientX : e.clientX;
  const clientY = e.touches ? e.touches[0].clientY : e.clientY;
  const col = Math.floor(((clientX - rect.left) * scaleX) / cellSize);
  const row = Math.floor(((clientY - rect.top)  * scaleY) / cellSize);
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
  return row * COLS + col;
}

function paintCell(idx) {
  if (idx < 0 || isRunning) return;

  if (currentTool === 'start') {
    if (idx === endNode) return;
    if (startNode >= 0) grid[startNode] = CELL.OPEN;
    startNode = idx; grid[idx] = CELL.START;
  } else if (currentTool === 'end') {
    if (idx === startNode) return;
    if (endNode >= 0) grid[endNode] = CELL.OPEN;
    endNode = idx; grid[idx] = CELL.END;
  } else if (currentTool === 'wall') {
    if (idx === startNode || idx === endNode) return;
    grid[idx] = CELL.WALL;
  } else if (currentTool === 'erase') {
    if (idx === startNode) startNode = -1;
    else if (idx === endNode) endNode = -1;
    grid[idx] = CELL.OPEN;
    visitedSet[idx] = 0;
    pathSet[idx] = 0;
  }
  render();
}

canvas.addEventListener('mousedown',  e => { isPainting = true;  paintCell(cellFromEvent(e)); });
canvas.addEventListener('mousemove',  e => { if (isPainting) paintCell(cellFromEvent(e)); });
canvas.addEventListener('mouseup',    ()  => { isPainting = false; });
canvas.addEventListener('mouseleave', ()  => { isPainting = false; });
canvas.addEventListener('touchstart', e => { e.preventDefault(); isPainting = true;  paintCell(cellFromEvent(e)); }, { passive: false });
canvas.addEventListener('touchmove',  e => { e.preventDefault(); if (isPainting) paintCell(cellFromEvent(e)); },  { passive: false });
canvas.addEventListener('touchend',   e => { e.preventDefault(); isPainting = false; });

/* ────────────────────────────────────────────────────────────
   10. TOOLBAR WIRING
   ──────────────────────────────────────────────────────────── */
// Algorithm selector
document.querySelectorAll('[data-algo]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('[data-algo]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentAlgo = btn.dataset.algo;
    document.getElementById('algo-badge').textContent = currentAlgo === 'astar' ? 'A*' : 'Dijkstra';
  });
});

// Tool selector
document.querySelectorAll('[data-tool]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('[data-tool]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentTool = btn.dataset.tool;
  });
});

// Speed slider
const speedSlider = document.getElementById('speed-slider');
const speedLabel  = document.getElementById('speed-label');
const SPEED_NAMES = { 1: 'Slow', 2: 'Medium', 3: 'Normal', 4: 'Fast', 5: 'Instant' };
speedSlider.addEventListener('input', () => {
  const v = parseInt(speedSlider.value);
  animDelay  = SPEED_MAP[v];
  speedLabel.textContent = SPEED_NAMES[v];
});

// Grid size slider
const sizeSlider = document.getElementById('size-slider');
const sizeLabel  = document.getElementById('size-label');
sizeSlider.addEventListener('input', () => {
  if (isRunning) return;
  const cols = parseInt(sizeSlider.value);
  const rows = Math.round(cols * (2/3));
  sizeLabel.textContent = `${cols}×${rows}`;
  initGrid(cols, rows);
  resize();
});

// Action buttons
document.getElementById('btn-run').addEventListener('click', runPathfind);
document.getElementById('btn-maze').addEventListener('click', generateMaze);
document.getElementById('btn-clear-path').addEventListener('click', () => { if (!isRunning) { clearPath(); render(); } });
document.getElementById('btn-clear-all').addEventListener('click', () => {
  if (!isRunning) { clearAll(); updateStats(null, null); document.getElementById('stat-time').textContent = '—'; render(); }
});

// Keyboard shortcuts
document.addEventListener('keydown', e => {
  if (e.key === ' ' || e.key === 'Enter') runPathfind();
  if (e.key === 'c' || e.key === 'C') { clearPath(); render(); }
  if (e.key === 'r' || e.key === 'R') clearAll();
  if (e.key === 'm' || e.key === 'M') generateMaze();
  if (e.key === 'w') document.getElementById('btn-wall').click();
  if (e.key === 's') document.getElementById('btn-start').click();
  if (e.key === 'e') document.getElementById('btn-end').click();
  if (e.key === 'd') document.getElementById('btn-erase').click();
});

/* ────────────────────────────────────────────────────────────
   11. RESIZE OBSERVER
   ──────────────────────────────────────────────────────────── */
const ro = new ResizeObserver(() => resize());
ro.observe(document.getElementById('grid-container'));

/* ────────────────────────────────────────────────────────────
   12. BOOT
   ──────────────────────────────────────────────────────────── */
async function boot() {
  const overlay = document.getElementById('grid-overlay');
  const overlayMsg = document.getElementById('overlay-msg');
  overlay.classList.remove('hidden');
  overlayMsg.textContent = 'Initializing engine…';

  // Try WASM
  const wasmOk = await tryLoadWasm();
  const engineLabel = wasmOk ? '⚡ C++ WebAssembly' : '🟡 JS Fallback';
  document.getElementById('stat-engine').textContent = engineLabel;

  // Init grid
  initGrid(30, 20);
  resize();

  overlay.classList.add('hidden');
  showToast('Ready! Click to place walls, then hit Find Path (or press Space).');
}

boot();
