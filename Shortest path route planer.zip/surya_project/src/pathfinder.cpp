/**
 * pathfinder.cpp
 * ─────────────────────────────────────────────────────────
 * Grid-based shortest-path engine implementing A* algorithm
 * with a custom min-heap priority queue built from scratch.
 *
 * Compiled to WebAssembly via Emscripten:
 *   emcc pathfinder.cpp -O3 -o ../wasm/pathfinder.js \
 *        -s EXPORTED_FUNCTIONS='["_findPath","_getPathLength","_freeMemory","_malloc","_free"]' \
 *        -s EXPORTED_RUNTIME_METHODS='["HEAPU8","HEAP32","ccall","cwrap"]' \
 *        -s ALLOW_MEMORY_GROWTH=1 \
 *        -s MODULARIZE=1 \
 *        -s EXPORT_NAME="PathfinderModule"
 */

#include <emscripten/emscripten.h>
#include <vector>
#include <cmath>
#include <cstring>
#include <climits>
#include <algorithm>

/* ═══════════════════════════════════════════════════════════
   1. CUSTOM MIN-HEAP PRIORITY QUEUE
   A classic binary min-heap keyed on (fScore, nodeIndex).
   ═══════════════════════════════════════════════════════════ */

struct PQNode {
    float cost;
    int   index;

    bool operator>(const PQNode& other) const {
        return cost > other.cost;
    }
};

class MinHeap {
private:
    std::vector<PQNode> heap;

    void siftUp(int i) {
        while (i > 0) {
            int parent = (i - 1) / 2;
            if (heap[parent] > heap[i]) {
                std::swap(heap[parent], heap[i]);
                i = parent;
            } else break;
        }
    }

    void siftDown(int i) {
        int n = (int)heap.size();
        while (true) {
            int smallest = i;
            int left     = 2 * i + 1;
            int right    = 2 * i + 2;

            if (left  < n && heap[left]  > heap[smallest] == false && heap[left].cost  < heap[smallest].cost) smallest = left;
            if (right < n && heap[right].cost < heap[smallest].cost) smallest = right;

            if (smallest != i) {
                std::swap(heap[i], heap[smallest]);
                i = smallest;
            } else break;
        }
    }

public:
    bool empty() const { return heap.empty(); }
    int  size()  const { return (int)heap.size(); }

    void push(float cost, int index) {
        heap.push_back({cost, index});
        siftUp((int)heap.size() - 1);
    }

    PQNode pop() {
        PQNode top = heap[0];
        heap[0] = heap.back();
        heap.pop_back();
        if (!heap.empty()) siftDown(0);
        return top;
    }

    PQNode peek() const { return heap[0]; }
};

/* ═══════════════════════════════════════════════════════════
   2. GRAPH / GRID HELPERS
   ═══════════════════════════════════════════════════════════ */

static int   g_cols   = 0;
static int   g_rows   = 0;
static int*  g_result = nullptr;
static int   g_resultLen = 0;

// 8-directional movement (including diagonals)
static const int DR[] = {-1, -1, -1,  0,  0,  1,  1,  1};
static const int DC[] = {-1,  0,  1, -1,  1, -1,  0,  1};
static const float MOVE_COST[] = {1.414f, 1.0f, 1.414f, 1.0f, 1.0f, 1.414f, 1.0f, 1.414f};

inline float heuristic(int a, int b, int cols) {
    // Octile distance — admissible heuristic for 8-directional grid
    int ar = a / cols, ac = a % cols;
    int br = b / cols, bc = b % cols;
    int dx = abs(ac - bc), dy = abs(ar - br);
    return 1.0f * (dx + dy) + (1.414f - 2.0f) * std::min(dx, dy);
}

/* ═══════════════════════════════════════════════════════════
   3. A* SEARCH ALGORITHM
   grid:  flat array of size rows*cols
          0 = open, 1 = wall, 2 = start, 3 = end
   Returns pointer to result array; length stored in g_resultLen.
   First element = path length (in cells), rest = cell indices.
   ═══════════════════════════════════════════════════════════ */

extern "C" {

EMSCRIPTEN_KEEPALIVE
int* findPath(int* grid, int rows, int cols, int startNode, int endNode) {
    // Free previous result
    if (g_result) { delete[] g_result; g_result = nullptr; g_resultLen = 0; }

    g_rows = rows;
    g_cols = cols;
    int n  = rows * cols;

    std::vector<float> gScore(n, 1e30f);
    std::vector<float> fScore(n, 1e30f);
    std::vector<int>   cameFrom(n, -1);
    std::vector<bool>  closed(n, false);
    std::vector<int>   visitOrder;  // order cells were finalized (for animation)

    gScore[startNode] = 0.0f;
    fScore[startNode] = heuristic(startNode, endNode, cols);

    MinHeap pq;
    pq.push(fScore[startNode], startNode);

    bool found = false;

    while (!pq.empty()) {
        PQNode cur = pq.pop();
        int    u   = cur.index;

        if (closed[u]) continue;
        closed[u] = true;
        visitOrder.push_back(u);

        if (u == endNode) { found = true; break; }

        int ur = u / cols, uc = u % cols;

        for (int d = 0; d < 8; d++) {
            int nr = ur + DR[d];
            int nc = uc + DC[d];
            if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue;

            int v = nr * cols + nc;
            if (grid[v] == 1 || closed[v]) continue;  // wall or already settled

            // For diagonal moves, ensure both adjacent cells are open
            if (d == 0 || d == 2 || d == 5 || d == 7) {
                int r1 = ur + DR[d], c1 = uc;
                int r2 = ur, c2 = uc + DC[d];
                if (r1 >= 0 && r1 < rows && c1 >= 0 && c1 < cols && grid[r1*cols+c1] == 1) continue;
                if (r2 >= 0 && r2 < rows && c2 >= 0 && c2 < cols && grid[r2*cols+c2] == 1) continue;
            }

            float tentative = gScore[u] + MOVE_COST[d];
            if (tentative < gScore[v]) {
                cameFrom[v] = u;
                gScore[v]   = tentative;
                fScore[v]   = tentative + heuristic(v, endNode, cols);
                pq.push(fScore[v], v);
            }
        }
    }

    // Reconstruct path
    std::vector<int> path;
    if (found) {
        int cur = endNode;
        while (cur != -1) { path.push_back(cur); cur = cameFrom[cur]; }
        std::reverse(path.begin(), path.end());
    }

    // Pack result: [visitCount, visit0..visitN, pathLen, path0..pathM]
    int visitCount = (int)visitOrder.size();
    int pathLen    = (int)path.size();
    g_resultLen    = 1 + visitCount + 1 + pathLen;

    g_result    = new int[g_resultLen];
    g_result[0] = visitCount;
    for (int i = 0; i < visitCount; i++) g_result[1 + i] = visitOrder[i];
    g_result[1 + visitCount] = pathLen;
    for (int i = 0; i < pathLen; i++) g_result[1 + visitCount + 1 + i] = path[i];

    return g_result;
}

EMSCRIPTEN_KEEPALIVE
int getResultLength() { return g_resultLen; }

EMSCRIPTEN_KEEPALIVE
void freeResult() {
    if (g_result) { delete[] g_result; g_result = nullptr; g_resultLen = 0; }
}

} // extern "C"
